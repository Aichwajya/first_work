<?php
session_start();
if(isset($_SESSION['email']))
{
    $name=$_POST['name'];
    $add=$_POST['add'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];
    $pass=$_POST['pass'];
    $age=$_POST['age'];
    $gender=$_POST['gender'];
	include('../function.php');
$cn=makeconnection();
	$query="SELECT * FROM `donarregistration` WHERE `email`='".$_SESSION['email']."'";
	$result=mysqli_query($cn,$query);
	$r=mysqli_fetch_array($result);
    if($pass==$r['pwd'])
    {
        
    $target_dir = "../donor_pic/";
			$target_file = $target_dir . basename($_FILES["dp"]["name"]);
            if($target_file!=$target_dir)
            {
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image
			$check = getimagesize($_FILES["dp"]["tmp_name"]);
			if($check !== false) {
				//  echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			}
			else
			{
				echo "File is not an image.";
				$uploadOk = 0;
				}
				// Check if file already exists
				if (file_exists($target_file)) {
					echo "Sorry, file already exists.";
					$uploadOk = 0;
					}
					//aloow certain file formats
					if($imageFileType != "jpg" && $imageFileType !="png" && $imageFileType !="jpeg" && $imageFileType !="gif"){
						echo "sorry, only jpg, jpeg, Png & gif files are allowed.";
						$uploadok=0;
						}
						else
						{
							if(move_uploaded_file($_FILES["dp"]["tmp_name"], $target_file)){
							unlink($target_dir.$r['pic']);
								$s="UPDATE `donarregistration` SET `name`='".$name."',`gender`='".$gender."',`age`='".$age."',`mobile`='".$mobile."',`email`='".$email."',`pic`='".basename($_FILES["dp"]["name"])."',`address`='".$add."' WHERE `email`='".$_SESSION['email']."'";
                                mysqli_query($cn,$s) or die("ERROR IN QUERY.");

								
									echo "<script>alert('Successfully Updated'); window.location.href='index.php';</script>";
								
							}
								else
								{
									echo "<script>alert('sorry there was an error uploading your file..'); window.location.href='registration.php';</script>";
								}
							}
            }
            else{
                $s="UPDATE `donarregistration` SET `name`='".$name."',`gender`='".$gender."',`age`='".$age."',`mobile`='".$mobile."',`email`='".$email."',`address`='".$add."' WHERE `email`='".$_SESSION['email']."'";
                                mysqli_query($cn,$s) or die("ERROR IN QUERY.");

								
									echo "<script>alert('Successfully Updated'); window.location.href='index.php';</script>";
                
            }
			
}
echo "<script>alert('Incorrect Password.'); window.location.href='updateprofile.php';</script>";
}
else
{
	header("location:../login.php");
	
}
?>