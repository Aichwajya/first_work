<?php
session_start();
if(isset($_SESSION['email']))
{
	include('../function.php');
$cn=makeconnection();
	$query="SELECT * FROM `donarregistration` WHERE `email`='".$_SESSION['email']."'";
	$result=mysqli_query($cn,$query);
	$r=mysqli_fetch_array($result);
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Blood Bank informtion System(BBIS)</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
	    <h1><a href="../index.php">BBIS</a></h1>
				 <h4>(Blood Bank Info. System)</h4>
	   </div>
	   <div class="header-icons">
	   	 <ul>
	   	 	<li><a href="#" class="fb"> </a></li>
	   	 	<li><a href="#" class="twit"> </a></li>
	   	 	<li><a href="#" class="gmail"> </a></li>
	   	 	<li><a href="#" class="dri"> </a></li>
	   	 </ul>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
	<div>
	 &nbsp;
	 </div>
<div class="top-nav-main">
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<?php require('header.php');?>
	  </div>
  </div>		
</div>
 <div class="container well" style="margin-top: 50px">



            <div class="panel-body" style="border: none" >
			
                
               <b style="font-size: x-large;">UPDATE YOUR PROFILE</b> 
                
                <br>
                <br>
				
                
                <form method="post" action="update_db.php" enctype="multipart/form-data">
                    
                    
             <ul class="list-group">
            <li class="list-group-item">Donor Name :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="text" name="name" required="required" value="<?php echo $r['name']; ?>" placeholder="Please enter your donor name" ></li>
                 
                   <li class="list-group-item">Your Current DP :
                 <?php
				 echo "<img style='height:130px;width:130px;border:solid;' src='../donor_pic/".$r['pic']."'>";
				 ?>
				   </li>
                   <li class="list-group-item">Upload a new DP :</li>
                
                <li class="list-group-item"><input type="file" name="dp"></li>
                 
        
            <li class="list-group-item">Gender :</li>
            
                 <li class="list-group-item">
            <?php
			if($r['gender']=="male")
			{
			?>
                 <label class="radio-inline">
               <input name="gender" type="radio" checked value="male" >Male
           </label>
                
                 <label class="radio-inline">
               <input name="gender" type="radio" value="female">Female
           </label>
            <?php
			}
			else if($r['gender']=="female")
			{
				?>
				
                 <label class="radio-inline">
               <input name="gender" type="radio" value="male" >Male
           </label>
                
                 <label class="radio-inline">
               <input name="gender" type="radio" checked value="female">Female
           </label>
				<?php
			}
			?>
            
            </li>
                 
                    </ul>
                 
            
            <ul class="list-group">
            <li class="list-group-item">Date of Birth :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="date" value="<?php echo $r['age']; ?>" name="age" required="required"
			placeholder="Please enter your age" /></li>
       
            <li class="list-group-item">Mobile no :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="number" name="mobile" value="<?php echo $r['mobile']; ?>" required="required"
			placeholder="Please enter your mobile no." /></li>
     
                    <li class="list-group-item">E-Mail :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="email" name="email" required="required" value="<?php echo $r['email']; ?>" placeholder="enetr your e-mail ID" ></li>
                
                
                <li class="list-group-item">Address :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="text" name="add" value="<?php echo $r['address']; ?>" required="required"
			placeholder="Please enter your address" ></li>
              
                
                <li class="list-group-item">Password :</li>
            <li class="list-group-item"><input style="width:80%;height:45%" type="password" name="pass" required="required"
			placeholder="Please enter your password" ></li>
               
               
                
                    </ul>
								
                
                <center>   
                    
                    <input style="width:20%;height:5%"type="submit" value="UPDATE" name="sbmt" style="border:0px; ">
                    
                    </center>
                    </form>
                    
		
                
                </div>	
		   
			</div>
 </div>
				
	
		<?php
		for($a=1;$a<=9;$a++)
        
    {
        echo'<br>';
    }
    
		?>

 <div class="clear"></div>
 
<div class="footer">
	<div class="container">
		<div class="footer-main">
			<div class="col-md-4 ftr-grid">
				<h3>Navigation</h3>
				<ul>
					<li><a href="index.php">Home</a></li>
				</ul>
			</div>
			<div class="col-md-4 ftr-grid">
				
			</div>
		
			<div class="col-md-4 ftr-grid">
				<h3>Keep In Touch</h3>
				<div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-map-marker">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>Kaziranga University, Koraikhuwa, JORHAT-785006, ASSAM</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-earphone">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>+91 1800-265-2020</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-envelope">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>BBIS.ku17@gmail.com</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			</div>
			<div class="clearfix"> </div>		
		</div>
	</div>
</div>
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <p>© 2017 Donate. All Rights Reserved | Design by Aichwajya, Nawab, Nishanta </p>
    	 </div>
    </div>
</div>
</body>
</html>
<?php
}
else
{
	header("location:../login.php");
	
}
?>


