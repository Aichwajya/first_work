<ul class="res">  
				<li><a style="font-size:14px" href="index.php">Home</a></li>
				<li><a style="font-size:14px" href="chngpwd.php">Change Password</a></li>
				
				<li><a style="font-size:14px" href="updateprofile.php">Update Profile</a></li>
			   <li><a style="font-size:14px" href="logout.php">Logout</a></li>
			   	   
			   
		</ul>

							 <script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {

								  });
								 });
							</script>
