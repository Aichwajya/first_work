<?php
session_start();
if(isset($_SESSION['email']))
{
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Blood Bank informtion System(BBIS)</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<script src="js/jquery-1.11.0.min.js"></script>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<!--google fonts-->
</head>
<body>
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
	    <h1><a href="../index.php">BBIS</a></h1>
				 <h4>(Blood Bank Info. System)</h4>
	   </div>
	   <div class="header-icons">
	   	 <ul>
	   	 	<li><a href="#" class="fb"> </a></li>
	   	 	<li><a href="#" class="twit"> </a></li>
	   	 	<li><a href="#" class="gmail"> </a></li>
	   	 	<li><a href="#" class="dri"> </a></li>
	   	 </ul>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
	<div>
	 &nbsp;
	 </div>
<div class="top-nav-main">
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
				<?php require('header.php');?>
	  </div>
  </div>		
</div>
<div style="height:400px; width:1000px; margin:auto; margin-top:70px; margin-bottom:50px; background-color: #ddd; border: none;">

  
		 <div class="panel-body" style="border: none" >
			
                
               <b style="font-size: x-large ;"> CHANGE PASSWORD</b> 
                
                <br>
                <br>
				
				<form method="post" enctype="multipart/form-data">
				
		
		  <ul class="list-group">
			
            <li class="list-group-item">Old PassWord :</li>
			<li class="list-group-item">
            <input type="password" style="width:600px;height:25px" name="t2" required="required"
	   pattern="[a-zA-Z0-9]{2,10}" Placeholder="Enter your current password" /></li></br>
            
            
            
        <li class="list-group-item">  New PassWord : </li>
		<li class="list-group-item">
        <input type="password" style="width:600px;height:25px" name="t3" required="required"
	    pattern="[a-zA-Z0-9]{2,10}" Placeholder="enter a new password" /></li>
 </br>
 
 
        <li class="list-group-item" > Re-Enter New PassWord :
		</li><li class="list-group-item"><input type="password" style="width:600px;height:25px"  name="t4" required="required"
	    pattern="[a-zA-Z0-9]{2,10}" Placeholder="Re-enter the new password" /></li>
   </br>   
        </ul>
      
          <div>
                
                    <center>
                    
                    <input style="width:20%;height:5%"type="submit" value="SUBMIT" name="sbmt" style="border:0px; ">
                    
                    </center>
                    
                    
		
                
                </div>	
        </form>
	</div>
	
	
	
<?php
include('../function.php'); 
if(isset($_POST["sbmt"])) 
{
	if($_POST["t3"]==$_POST["t4"])
	{
	$cn=makeconnection();
	$email=$_SESSION["email"];

			$s="select * from donarregistration where email='".$email."' and  pwd='".$_POST["t2"] ."'";
			
	$q=mysqli_query($cn,$s);
	$r=mysqli_num_rows($q);
	
	if($r>0)
	{
	
	$s1="update donarregistration set pwd='" . $_POST["t3"]  ."' where email='" .$_SESSION["email"] ."'";
	mysqli_query($cn,$s1);
	mysqli_close($cn);
	echo "<script>alert('Record Update');</script>";

	}
	else
	{
		echo "<script>alert('Invalid old Password');</script>";
	}
		
		}
else
{
	echo "<script>alert('Please enter the same new password twice appropriately.');</script>";
}
}
	

?>

</div>
		<?php
		for($a=1;$a<=9;$a++)
        
    {
        echo'<br>';
    }
    
		?>


 

 
 
<div class="footer">
	<div class="container">
		<div class="footer-main">
			<div class="col-md-4 ftr-grid">
				<h3>Navigation</h3>
				<ul>
					<li><a href="index.php">Home</a></li>
				 
				</ul>
			</div>
			<div class="col-md-4 ftr-grid">
				
			</div>
		
			<div class="col-md-4 ftr-grid">
				<h3>Keep In Touch</h3>
				<div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-map-marker">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>Kaziranga University, Koraikhuwa, JORHAT-785006, ASSAM</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-earphone">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>+91 1800-265-2020</p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			   <div class="ftr-icons">
			    	  	 <div class="ftr-iblock">
			        	   <span class="glyphicon glyphicon-envelope">  </span>
			        	 </div>
			        	 <div class="ftr-text">
			        	 	<p>BBIS.ku17@gmail.com</a></p>
			        	 </div>
			        	 <div class="clearfix"> </div>
			   </div>
			</div>
			<div class="clearfix"> </div>		
		</div>
	</div>
</div>
<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <p>© 2017 Donate. All Rights Reserved | Design by Aichwajya, Nawab, Nishanta </p>
    	 </div>
    </div>
</div>
</body>
</html>
<?php
}
else
{
	header("location:../login.php");
	
}
?>
