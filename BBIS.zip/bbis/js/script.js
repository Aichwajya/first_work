function validation()
{
if(isNaN(document.getElementById("phone").value) || document.getElementById("phone").value.length!=10)
   {
	   alert("PLEASE ENTER A 10 digit PHONE NO.");
	    document.getElementById("phone").focus();
		return false;
	   
   }


var y=document.getElementById("age").value;
    if(y<18 || y>80 || y=='')
    {
        alert("To be a donor you must be above 18 year age");
        document.getElementById("year").focus();
        return false;

    }
}