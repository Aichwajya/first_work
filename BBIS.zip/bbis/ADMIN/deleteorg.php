<?php
session_start();
if(isset($_SESSION['username']))
{
    include('function.php');
    $id=$_GET['id'];
    $cn = makeconnection();
    $s = "DELETE FROM `org_reg` WHERE `email`='".$id."'";
    mysqli_query($cn, $s);
    header("location:upbloodgroup.php");
}
else
{
    header("location:admimlogin.php");
}
?>