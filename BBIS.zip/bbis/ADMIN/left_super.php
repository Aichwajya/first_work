<?php if(!isset($_SESSION)) {session_start();}  ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Blood Bank informtion System(BBIS)</title>
<link href="StyleSheet.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!--slider-->
<link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
<script src="js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider.js" type="text/javascript"></script>
 <script type="text/javascript">
     $(function () {
         SyntaxHighlighter.all();
     });
     $(window).load(function () {
         $('.flexslider').flexslider({
             animation: "slide",
             animationLoop: false,
             itemWidth: 210,
             itemMargin: 5,
             minItems: 2,
             maxItems: 4,
             start: function (slider) {
                 $('body').removeClass('loading');
             }
         });
     });
  </script>
</head>
<body>

 
     
<table style="width:1000px; height:200px"> 

<br>
<br>
    <tr><td class="lefttd"style="font-size:20px; color:#000000; font-weight:bold"><a href="adduser.php">Add Admin</a></td>
        <td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="upuser.php">Update Admin</a></td>
<td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="deluser.php">Delete Admin</a></td></tr>



<tr><td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="addbloodgroup.php">Delete Donor</a></td>
    <td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="upbloodgroup.php">Delete Blood Bank/Org.</a></td>
    <td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="request.php">View Request</a></td>
    <td class="lefttd" style="font-size:20px; color:#000000; font-weight:bold"><a href="contact.php">Contact Details</a>
    </td>

</table>

</body>
</html>