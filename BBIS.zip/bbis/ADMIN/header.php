<ul class="res">

			
			<li><a href="../index.php" style="font-size: 14px" target="_blank">Preview</a></li>
			<li><a href="logout.php" style="font-size: 14px">Logout</a></li>
		</ul>
<!-- script-for-menu -->
							 <script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {

								  });
								 });
							</script>
			<!-- /script-for-menu -->