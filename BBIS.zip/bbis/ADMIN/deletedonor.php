<?php
session_start();
if(isset($_SESSION['username']))
{
    include('function.php');
    $id=$_GET['id'];
    $cn = makeconnection();
    $s = "DELETE FROM `donarregistration` WHERE `donar_id`='".$id."'";
    mysqli_query($cn, $s);
    header("location:addbloodgroup.php");
}
else
{
    header("location:admimlogin.php");
}
?>