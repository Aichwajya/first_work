<?php if(!isset($_SESSION)) { session_start(); } ?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Blood Bank informtion System(BBIS)</title>
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <!-- Custom Theme files -->
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
    <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!--Google Fonts-->
    <link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
    <!--google fonts-->
</head>
<body>

<!--banner start here-->
<div class="banner1">
    <div class="header1">
        <div class="container">
            <div class="header-main">
                <div class="logo">
                    <h1><a href="index.php">BBIS</a></h1>
                    <h4>(Blood Bank Info. System)</h4>
                </div>
                <div class="header-icons">
                    <ul>
                        <li><a href="#" class="fb"> </a></li>
                        <li><a href="#" class="twit"> </a></li>
                        <li><a href="#" class="gmail"> </a></li>
                        <li><a href="#" class="dri"> </a></li>
                    </ul>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <div class="top-nav-main">
        <div class="top-nav">
            <span class="menu"> <img src="images/icon.png" alt=""></span>
            <?php require('header.php');?>
        </div>
    </div>
</div>
<?php
if($_SESSION['loginstatus']=="")
{
    header("location:admimlogin.php");
}
?>
<center>
    <?php
    if($_SESSION['username']=='bbis') {
        ?>
        <div style="width:1500px; height:300px; background: #58abab">

            <?php include('left_super.php'); ?>
        </div>
        <?php
    }
    else
    {
        ?>
        <div style="width:1500px; height:300px; background: #58abab">

            <?php include('left.php'); ?>
        </div>
        <?php
    }
    ?>


    <?php include('function.php'); ?>

    <div style=" background: #58abab">

        <div style=" height:auto">
            <form method="post" enctype="multipart/form-data">
                <table cellpadding="0" cellspacing="0" width="500px" style="margin:auto">
                    <tr>
                        <td> <div class="container well" style="margin-top: 50px">
                                <table cellpadding="0" cellspacing="0" width="800px" style="margin:auto; border-color: blue">

                                    <tr><td  align="center"><b style="font-size: x-large;color: #b0b0b0;"> List of CONTACT US MESSAGES: </b></td></tr><br>

                                    <?php
                                    $cn=makeconnection();
                                    $s="SELECT * FROM `contacts`";
                                    $result=mysqli_query($cn,$s);
                                    $r=mysqli_num_rows($result);
                                    $n=0;
                                    while($data=mysqli_fetch_array($result))
                                    {
                                        ?>
                                        <tr><td><br><br><div class="panel-body">
                                                    <table  cellpadding="0" cellspacing="0" width="630px" style="margin:auto; border:none; border:0px solid blue;" class="tableborder">
                                                        <tr>
                                                            <td width="500px" height="50px" style="vertical-align:top">


                                                                <table align="center" cellpadding="0"  style="border:none">
                                                                    <tr><td colspan="2">&nbsp;</td></tr>
                                                                    <tr><td width="200px"><span class="title">Name:</span></td><td>  <?php echo $data[1]; ?></td></tr>
                                                                    <tr><td><span class="title">Email:</span></td><td><?php echo $data[2]; ?></td></tr>
                                                                    <tr><td><span class="title">Mobile:</span></td><td><?php echo $data[3]; ?></td></tr>
                                                                    <tr><td style="width:24px"><span class="title">Subject:</span></td><td><?php echo $data[4]; ?></td></tr>




                                                                </table>
                                                            </td></tr>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php }
                                    ?>
                                </table>
                            </div>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

</center>
<!--terisa block end here-->
<!--footer start here-->
<div class="footer">
    <div class="container">
        <div class="footer-main">
            s
            <div class="col-md-4 ftr-grid">

            </div>

            <div class="col-md-4 ftr-grid">
                <h3>Keep In Touch</h3>
                <div class="ftr-icons">
                    <div class="ftr-iblock">
                        <span class="glyphicon glyphicon-map-marker">  </span>
                    </div>
                    <div class="ftr-text">
                        <p>Kaziranga University, Koraikhuwa, JORHAT-785006, ASSAM</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="ftr-icons">
                    <div class="ftr-iblock">
                        <span class="glyphicon glyphicon-earphone">  </span>
                    </div>
                    <div class="ftr-text">
                        <p>+91 1800-265-2020</p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
                <div class="ftr-icons">
                    <div class="ftr-iblock">
                        <span class="glyphicon glyphicon-envelope">  </span>
                    </div>
                    <div class="ftr-text">
                        <p><a href="BBIS@gmail.com91 1800-265-2020">BBIS@gmail.com</a></p>
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<!--footer end here-->
<!--copy rights start here-->
<div class="copy-right">
    <div class="container">
        <div class="copy-rights-main">
            <p>© 2017 Donate. All Rights Reserved | Design by Aichwajya, Nawab, Nishanta </p>
        </div>
    </div>
</div>
<!--copy right end here-->

</body>
</html>