<?php if(!isset($_SESSION)) { session_start(); } ?>

<!DOCTYPE HTML>
<html>
<head>
<title>Blood Bank informtion System(BBIS)</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Donate Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Karla:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Archivo+Narrow:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/style.css">
<!--google fonts-->
</head>
<body>

<!--banner start here-->
<div class="banner1">
	<div class="header1">
   <div class="container">
     <div class="header-main">
	   <div class="logo">
	    <h1><a href="../index.php">BBIS</a></h1>
				 <h4>(Blood Bank Info. System)</h4>
	   </div>
	   <div class="header-icons">
	   	 <ul>
	   	 	<li><a href="#" class="fb"> </a></li>
	   	 	<li><a href="#" class="twit"> </a></li>
	   	 	<li><a href="#" class="gmail"> </a></li>
	   	 	<li><a href="#" class="dri"> </a></li>
	   	 </ul>
	   </div>
	    <div class="clearfix"> </div>
      </div>
    </div>
  </div>
<div class="top-nav-main">
<div class="top-nav">
            	<span class="menu"> <img src="images/icon.png" alt=""></span>	
			
	  </div>
  </div>		
</div>	


<?php include('function.php'); ?>

<div class="login">
    <div class="container well" style="margin-top: 50px">
        <div class="panel-body">
     <form method="post" enctype="multipart/form-data">

   <table cellpadding="0" cellspacing="0" width="800px" height="300px" style="margin:auto; margin-top:35px;">
     <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
    <tr><td colspan="2" align="center"><b style="font-size: x-large;color: #b0b0b0;">ADMIN-LOGIN</b></td></tr>
    
     <tr><td colspan="2">&nbsp;</td></tr>  <tr><td colspan="2">&nbsp;</td></tr> 
                <tr><td align="right"><img src="../photu/admin.gif" width="200px" height="200px" /></td>
                    <td style="vertical-align:top"><table cellpadding="0" cellspacing="0" height="200px">             


<tr><td class="lefttd">User Name: &nbsp;</td><td><input type="text" name="t1" /></td>
&nbsp; <td class="lefttd">Password: &nbsp;</td><td><input type="password"name="t2" /></td></tr>


<tr><td>&nbsp;</td>
<td colspan="2" align="center"><input type="submit" value="Log In" name="sbmt" style="border:0px; background:linear-gradient(#c0c0c0,#D50000); width:100px; height:30px; border-radius:10px 1px 10px 1px; box-shadow:1px 1px 5px black; color:white; font-weight:bold; font-size:14px; text-shadow:1px 1px 6px black; "></td></tr>

                       
              
</table>
</td></tr></table>

     </div>
		
</form>
    </div>
</div>


<div class="copy-right">
	<div class="container">
		 <div class="copy-rights-main">
    	    <p>© 2017 Donate. All Rights Reserved | Design by Aichwajya, Nawab, Nishanta </p>
         </div>
    </div>
</div>


	

				
			   
	
	


<?php
$_SESSION['loginstatus']="";
if(isset($_POST["sbmt"])) 
{
	
	$cn=makeconnection();			

			$s="select *from users where username='" . $_POST["t1"] . "' and pwd='" .$_POST["t2"] . "'";
			
	$q=mysqli_query($cn,$s);
	$r=mysqli_num_rows($q);

	

	if($r>0)
	{
		$_SESSION["username"]=$_POST["t1"];
		$_SESSION['loginstatus']="yes";

header("location:index.php");
	}
	else {
        $query = "SELECT * FROM `superadmin` WHERE `username`='" . $_POST["t1"] . "' and `password`='" . $_POST["t2"] . "'";
        $q1 = mysqli_query($cn, $query);
        $r1 = mysqli_num_rows($q1);
        if ($r1 > 0) {
            $_SESSION["username"]=$_POST["t1"];
            $_SESSION['loginstatus']="yes";

            header("location:super.php");

        } else {
            echo "<script>alert('Invalid User Name Or Password');</script>";
        }
    }
		
		}	
	

?> 
</body>
</html>