<ul class="res">
			<li><a href="index.php" style="font-size: 14px">Home</a></li>

    <li><a href="registration.php"  style="font-size: 14px">Donor Reg.</a></li>
    <li><a href="reg_org.php" style="font-size: 14px">BloodBank Reg.</a></li>
			<li><a href="request.php"  style="font-size: 14px">Send Request   </a></li>
			<li><a href="search.php" style="font-size: 14px">Search</a></li>
			<li><a href="login.php" style="font-size: 14px">Donor Login</a></li>
			<li><a href="about.php" style="font-size: 14px">About Us</a></li>
			<li><a href="contact.php" style="font-size: 14px">Contact Us</a></li>

		</ul>
							 <script>
							   $( "span.menu" ).click(function() {
								 $( "ul.res" ).slideToggle( 300, function() {

								  });
								 });
							</script>